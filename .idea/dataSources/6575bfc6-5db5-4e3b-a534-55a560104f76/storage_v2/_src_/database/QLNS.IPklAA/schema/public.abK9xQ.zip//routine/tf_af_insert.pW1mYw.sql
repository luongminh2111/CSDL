create function tf_af_insert() returns trigger
    language plpgsql
as
$$
BEGIN

update nhanvien
set macv = new.macv
where manv=new.manv;

update thangtien 
set ngayketthuc=new.ngaytiepnhan
where new.manv=manv and new.mapb=mapb;

RETURN NEW;
END;
$$;

alter function tf_af_insert() owner to postgres;

