create function tf_af_delete() returns trigger
    language plpgsql
as
$$
BEGIN
delete from thangtien
where manv = old.manv;
RETURN NEW;
END;
$$;

alter function tf_af_delete() owner to postgres;

